# Tensorflow Models Evaluation

The code in this folder has been extracted and adapted from evaluation/evaluator code at https://github.com/tensorflow/models/tree/master/research/object_detection/utils

Original code is licensed Apache 2.0, Copyright Google Inc.
https://github.com/tensorflow/models/blob/master/LICENSE
 