from .parser_config import OpenImagesParserCfg, CocoParserCfg, VocParserCfg
from .parser_factory import create_parser
